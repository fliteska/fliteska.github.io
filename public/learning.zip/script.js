// When the show form button is clicked, unhide the form and hide the button.
document.querySelector("#showFormBtn")
  .addEventListener("click", function(event) {
    document.getElementById("userForm").classList.remove("hide");
    document.getElementById("exportBtn").classList.remove("hide");
    document.querySelector("#showFormBtn").classList.add("hide");
  });

let userData = []; // we'll store stuff here...

document.getElementById("userForm")
  .addEventListener("submit", function (event) {
    event.preventDefault(); // stop the form being submitted.
    const formData = {
      name: document.querySelector("#username").value,
      dob: document.querySelector("#dob").value,
      height: document.querySelector("#height").value,
      query: document.querySelector("#query").value,
    };
    userData.push(formData);
    this.reset();
    document.querySelector("#userDataOutput").textContent = JSON.stringify(userData);
  });

document.querySelector("#exportBtn")
  .addEventListener("click", function(event) {
    if (userData.length === 0) {
      alert("No data to export");
      return;
    }
    exportToExcel(userData);
  });

function exportToExcel(data) {
  let csvContent = "Name,Date of Birth,Height,Query\n";
  data.forEach(function(d) {
    csvContent += `${d.name},${d.dob},${d.height},${d.query}\n`
  });
  const blob = new Blob([csvContent], { type: "text/csv" });
  const anchor = document.createElement("a");
  anchor.href = window.URL.createObjectURL(blob);
  anchor.download = "users.csv";
  anchor.click();
}
